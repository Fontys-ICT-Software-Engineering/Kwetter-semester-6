﻿namespace ProfileService.DTOs
{
    public class ProfileDTO
    {
        public Guid id { get; set; }

        public string name { get; set; }

        public string userName { get; set; }

        public string adress { get; set; }

        public string bio { get; set; }

        //public string profilePicture { get; set; }
    }
}
