﻿namespace KweetService.DTOs.KweetDTO
{
    public class PostKweetDTO
    {
        public string Message { get; set; }

        public string User { get; set; }
        
    }
}
