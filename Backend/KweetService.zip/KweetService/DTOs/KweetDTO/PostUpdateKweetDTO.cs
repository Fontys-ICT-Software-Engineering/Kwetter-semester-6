﻿namespace KweetService.DTOs.KweetDTO
{
    public class PostUpdateKweetDTO
    {
        public Guid Id { get; set; }

        public string User { get; set; }

        public string Message { get; set; }
    }
}
