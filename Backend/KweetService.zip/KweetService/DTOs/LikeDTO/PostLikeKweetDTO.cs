﻿namespace KweetService.DTOs.LikeDTO
{
    public class PostLikeKweetDTO
    {
        public string KweetId { get; set; }

        public string UserId { get; set; }

    }
}
