﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Kweet.Migrations
{
    /// <inheritdoc />
    public partial class addedIsedited : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsEdited",
                table: "Kweets",
                type: "tinyint(1)",
                nullable: false,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsEdited",
                table: "Kweets");
        }
    }
}
