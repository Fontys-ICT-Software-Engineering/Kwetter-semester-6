﻿namespace AuthService.DTOs
{
    public class TokenDTO
    {
        public string Token { get; set; }

    }
}
