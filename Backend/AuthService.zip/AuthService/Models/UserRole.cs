﻿namespace AuthService.Models
{
    public enum UserRole
    {
        NORMAL = 0, ADMIN = 1
    }
}
